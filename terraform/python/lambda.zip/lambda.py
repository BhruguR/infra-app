def lambda_handler(event, context):
   message = 'Hello {} !'.format(event['key1'])
   print("HELLO")
   return {
       'message' : message
   }
    